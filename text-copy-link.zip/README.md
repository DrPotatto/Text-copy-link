# Text to Copy Link

A simple HTML tool to generate a link that automatically copies text to the clipboard.